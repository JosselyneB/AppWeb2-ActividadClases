// Definición de las entidades utilizando TypeScript

// Entidad Equipo
interface Equipo {
    id: number;
    descripcion: string;
    serie: string;
  }
  
  // Entidad Torneo
  interface Torneo {
    id: number;
    descripcion: string;
    // Un torneo tiene varios partidos
    partidos: Partido[];
  }
  
  // Entidad Partido
  interface Partido {
    id: number;
    idTorneo: number;
    idEquipo1: number;
    idEquipo2: number;
    golesEquipo1: number;
    golesEquipo2: number;
    observacion: string;
  }
  
  // Ejemplo de uso
  const equipo1: Equipo = {
    id: 1,
    descripcion: "Equipo A",
    serie: "Serie 1",
  };
  
  const equipo2: Equipo = {
    id: 2,
    descripcion: "Equipo B",
    serie: "Serie 2",
  };
  
  const partidoEjemplo: Partido = {
    id: 1,
    idTorneo: 123,
    idEquipo1: equipo1.id,
    idEquipo2: equipo2.id,
    golesEquipo1: 2,
    golesEquipo2: 1,
    observacion: "Partido emocionante",
  };
  
  const torneoEjemplo: Torneo = {
    id: 123,
    descripcion: "Torneo de Fútbol",
    partidos: [partidoEjemplo],
  };
  
  console.log("Equipo 1:", equipo1);
  console.log("Equipo 2:", equipo2);
  console.log("Partido Ejemplo:", partidoEjemplo);
  console.log("Torneo Ejemplo:", torneoEjemplo);

  






  // Definición de las interfaces
interface Equipo {
    id: number;
    descripcion: string;
    serie: string;
  }
  
  interface Torneo {
    id: number;
    descripcion: string;
    partidos: Partido[];
  }
  
  interface Partido {
    id: number;
    idTorneo: number;
    idEquipo1: number;
    idEquipo2: number;
    golesEquipo1: number;
    golesEquipo2: number;
    observacion: string;
  }
  
  // Ejemplo de uso con objetos tipados
  const equip1: Equipo = {
    id: 1,
    descripcion: "Equipo A",
    serie: "Serie 1",
  };
  
  const equip2: Equipo = {
    id: 2,
    descripcion: "Equipo B",
    serie: "Serie 2",
  };
  
  const partidEjemplo: Partido = {
    id: 1,
    idTorneo: 123,
    idEquipo1: equipo1.id,
    idEquipo2: equipo2.id,
    golesEquipo1: 2,
    golesEquipo2: 1,
    observacion: "Partido emocionante",
  };
  
  const tornEjemplo: Torneo = {
    id: 123,
    descripcion: "Torneo de Fútbol",
    partidos: [partidoEjemplo],
  };
  
  console.log("Equipo 1:", equipo1);
  console.log("Equipo 2:", equipo2);
  console.log("Partido Ejemplo:", partidoEjemplo);
  console.log("Torneo Ejemplo:", torneoEjemplo);
  









  // Definición de la entidad Equipo
interface Equipo {
    id: number;
    descripcion: string;
    serie: string;
  }
  
  // Definición de la entidad Torneo
  interface Torneo {
    id: number;
    descripcion: string;
  }
  
  // Definición de la entidad Partido
  interface Partido {
    id: number;
    idTorneo: number;
    idEquipo1: number;
    idEquipo2: number;
    golesEquipo1: number;
    golesEquipo2: number;
    observacion: string;
  }
  
  // Creación de objetos
  const equi1: Equipo = {
    id: 1,
    descripcion: "Equipo A",
    serie: "Serie 1",
  };
  
  const equi2: Equipo = {
    id: 2,
    descripcion: "Equipo B",
    serie: "Serie 2",
  };
  
  const torneo: Torneo = {
      id: 123,
      descripcion: "Torneo de Fútbol",
      partidos: []
  };
  
  const partido: Partido = {
    id: 1,
    idTorneo: torneo.id,
    idEquipo1: equipo1.id,
    idEquipo2: equipo2.id,
    golesEquipo1: 2,
    golesEquipo2: 1,
    observacion: "Partido emocionante",
  };
  
  // Creación del arreglo con los objetos
  const EnTransaccional: (Equipo | Torneo | Partido)[] = [equipo1, equipo2, torneo, partido];
  
  // Imprimir los elementos del arreglo
  EnTransaccional.forEach((elemento) => {
    console.log(elemento);
  });
  








  // Definición de la entidad Equipo
interface Equipo {
    id: number;
    descripcion: string;
    serie: string;
  }
  
  // Definición de la entidad Torneo
  interface Torneo {
    id: number;
    descripcion: string;
  }
  
  // Definición de la entidad Partido
  interface Partido {
    id: number;
    idTorneo: number;
    idEquipo1: number;
    idEquipo2: number;
    golesEquipo1: number;
    golesEquipo2: number;
    observacion: string;
  }
  
  // Creación de objetos (como en el ejemplo anterior)
  const equ1: Equipo = {
    id: 1,
    descripcion: "Equipo A",
    serie: "Serie 1",
  };
  
  const equ2: Equipo = {
    id: 2,
    descripcion: "Equipo B",
    serie: "Serie 2",
  };
  
  const tor: Torneo = {
      id: 123,
      descripcion: "Torneo de Fútbol",
      partidos: []
  };
  
  const part: Partido = {
    id: 1,
    idTorneo: torneo.id,
    idEquipo1: equipo1.id,
    idEquipo2: equipo2.id,
    golesEquipo1: 2,
    golesEquipo2: 1,
    observacion: "Partido emocionante",
  };
  
  // Creación del arreglo con los objetos
  const entidadTransaccional: (Equipo | Torneo | Partido)[] = [equipo1, equipo2, torneo, partido];
  
  // Función para eliminar un elemento por ID
  function eliminarElementoPorID(arr: (Equipo | Torneo | Partido)[], id: number): void {
    const index = arr.findIndex((elemento) => elemento.id === id);
    if (index !== -1) {
      arr.splice(index, 1);
      console.log(`Elemento con ID ${id} eliminado correctamente.`);
    } else {
      console.log(`No se encontró ningún elemento con ID ${id}.`);
    }
  }
  
  // Ejemplo de uso: Eliminar el equipo con ID 2
  eliminarElementoPorID(entidadTransaccional, 2);
  
  // Imprimir los elementos actualizados del arreglo
  console.log("Arreglo después de eliminar el elemento:");
  entidadTransaccional.forEach((elemento) => {
    console.log(elemento);
  });
  








  // Definición de la entidad Equipo
interface Equipo {
    id: number;
    descripcion: string;
    serie: string;
  }
  
  // Definición de la entidad Torneo
  interface Torneo {
    id: number;
    descripcion: string;
  }
  
  // Definición de la entidad Partido
  interface Partido {
    id: number;
    idTorneo: number;
    idEquipo1: number;
    idEquipo2: number;
    golesEquipo1: number;
    golesEquipo2: number;
    observacion: string;
  }
  
  // Creación de objetos (como en el ejemplo anterior)
  const equipo1: Equipo = {
    id: 1,
    descripcion: "Equipo A",
    serie: "Serie 1",
  };
  
  const equipo2: Equipo = {
    id: 2,
    descripcion: "Equipo B",
    serie: "Serie 2",
  };
  
  const torneo: Torneo = {
    id: 123,
    descripcion: "Torneo de Fútbol",
  };
  
  const partido: Partido = {
    id: 1,
    idTorneo: torneo.id,
    idEquipo1: equipo1.id,
    idEquipo2: equipo2.id,
    golesEquipo1: 2,
    golesEquipo2: 1,
    observacion: "Partido emocionante",
  };
  
  // Creación del arreglo con los objetos
  const entidadTransaccional: (Equipo | Torneo | Partido)[] = [equipo1, equipo2, torneo, partido];
  
  // Función para eliminar un elemento por ID y llamar al callback
  function eliminarElementoPorID(arr: (Equipo | Torneo | Partido)[], id: number, callback: (elementoEliminado: Equipo | Torneo | Partido) => void): void {
    const index = arr.findIndex((elemento) => elemento.id === id);
    if (index !== -1) {
      const elementoEliminado = arr.splice(index, 1)[0];
      console.log(`Elemento con ID ${id} eliminado correctamente.`);
      callback(elementoEliminado);
    } else {
      console.log(`No se encontró ningún elemento con ID ${id}.`);
    }
  }
  
  // Callback para mostrar el elemento eliminado
  function mostrarElementoEliminado(elemento: Equipo | Torneo | Partido): void {
    console.log("Elemento eliminado:");
    console.log(elemento);
  }
  
  // Ejemplo de uso: Eliminar el equipo con ID 2 y mostrarlo por consola
  eliminarElementoPorID(entidadTransaccional, 2, mostrarElementoEliminado);
  
  // Imprimir los elementos actualizados del arreglo
  console.log("Arreglo después de eliminar el elemento:");
  entidadTransaccional.forEach((elemento) => {
    console.log(elemento);
  });
  